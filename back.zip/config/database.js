module.exports = {
    development: {
        username: 'postgres',
        password: 'your_local_password',
        database: 'node_auth',
        host: 'localhost',
        dialect: 'postgres',
        logging: console.log
    },
    production: {
        username: 'ftpsafenet',
        password: '3Iw3^l0g5',
        database: 'safenetftpsafescap_ir_',
        host: 'localhost',
        port: 5432,
        dialect: 'postgres',
        logging: false,
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    }
}; 